/*
 * Copyright (C) 2010 Moduad Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.androidpn.client;

import java.io.File;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

/** 
 * Broadcast receiver that handles push notification messages from the server.
 * This should be registered as receiver in AndroidManifest.xml. 
 * 
 * @author Sehwan Noh (devnoh@gmail.com)
 */
public final class NotificationReceiver extends BroadcastReceiver {
	
	private static final int SUCCESS = 1;
	
	private static final int FAILED = 0;
	
    private BroadcastReceiver downloadCompleteReceiver;

    private static final String LOGTAG = LogUtil
            .makeLogTag(NotificationReceiver.class);
    
    DownloadManager dManager ;
    
    DownloadCompleteReceiver receiver;

    public NotificationReceiver() {
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(LOGTAG, "NotificationReceiver.onReceive()...");
        String action = intent.getAction();
        Log.d(LOGTAG, "action=" + action);			
        if (Constants.ACTION_SHOW_NOTIFICATION.equals(action)) {
            String notificationId = intent
                    .getStringExtra(Constants.NOTIFICATION_ID);
            String notificationApiKey = intent
                    .getStringExtra(Constants.NOTIFICATION_API_KEY);
            String notificationTitle = intent
                    .getStringExtra(Constants.NOTIFICATION_TITLE);
            String notificationMessage = intent
                    .getStringExtra(Constants.NOTIFICATION_MESSAGE);
            String notificationUri = intent
                    .getStringExtra(Constants.NOTIFICATION_URI);            
            String notificationSource_name = intent
                    .getStringExtra(Constants.NOTIFICATION_SOURCE_NAME);
            
            //add on 0423
/* */           String notificationResourceId = intent
                    .getStringExtra(Constants.NOTIFICATION_RESOURCEID);
            //add end
            
            String notificationFrom = intent
            		.getStringExtra(Constants.NOTIFICATION_FROM);
            String packetId = intent
    				.getStringExtra(Constants.PACKET_ID);
            
            Log.d(LOGTAG, "notificationId=" + notificationId);
            Log.d(LOGTAG, "notificationApiKey=" + notificationApiKey);
            Log.d(LOGTAG, "notificationTitle=" + notificationTitle);
            Log.d(LOGTAG, "notificationMessage=" + notificationMessage);
            Log.d(LOGTAG, "notificationUri=" + notificationUri);
            Log.d(LOGTAG, "notificationSource_name=" + notificationSource_name);
            
            Log.d(LOGTAG, "notificationResourceId=" + notificationResourceId);
            
            downloadCompleteReceiver = new DownloadCompleteReceiver(notificationSource_name,
            		notificationResourceId);
            
            registerDownloadCompleteReceiver(context);
            
            download(context, notificationUri, notificationSource_name);
            
            Notifier notifier = new Notifier(context);
            
            notifier.notify(notificationId, notificationApiKey,
                    notificationTitle, notificationMessage, notificationUri, notificationFrom, packetId);
        }
    }

    private int download(Context context, final String uri, final String source_name){
    	 if (uri != null
                 && uri.length() > 0
                 && (uri.startsWith("http:") || uri.startsWith("https:")
                         || uri.startsWith("tel:") || uri
                         .startsWith("geo:"))){
    		 dManager = (DownloadManager)context.getSystemService(Context.DOWNLOAD_SERVICE);
    		 DownloadManager.Request down = new DownloadManager.Request(Uri.parse(uri));
    		 down.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_MOBILE|DownloadManager.Request.NETWORK_WIFI); 
    		 down.setShowRunningNotification(true);
    		 down.setVisibleInDownloadsUi(false); 
    		 
    		 down.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,source_name);
    		 
    		 dManager.enqueue(down); 
    		 Log.d(LOGTAG, "download begin!");
    		 
    	 }else{
    		 return FAILED;
    	 }
    	 return SUCCESS;
    }
    
    //注册信息
    private void registerDownloadCompleteReceiver(Context context){
    	IntentFilter filter = new IntentFilter();
    	
    	filter.addAction(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
    	
    	context.registerReceiver(downloadCompleteReceiver, filter);
    	
    	Log.d(LOGTAG,"download complete receiver registerd!");
    }
    
    private void unregisterDownloadCompleteReceiver(Context context){
   	 	context.unregisterReceiver(downloadCompleteReceiver);
   }

}
