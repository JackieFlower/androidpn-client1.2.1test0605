
package org.androidpn.client;

import java.io.File;

import org.androidpn.laumanager.DBManager;

import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

class DownloadCompleteReceiver extends BroadcastReceiver { 
    private static final String LOGTAG = LogUtil
            .makeLogTag(DownloadCompleteReceiver.class);
    
    private String source_name = null ;
    private String resource_id =  null;
    private String url = null;
    private PackageManager pm;
    private DBManager dbManager;
    private String appLabel, pkgName;
    String defalutPath = null;
    String fullPath = null;
    
    public DownloadCompleteReceiver(String source_name, String resource_id){
    	this.source_name = source_name;
    	this.resource_id = resource_id;
    	defalutPath = Environment.getExternalStorageDirectory().getAbsolutePath() +
    										"/"+Environment.DIRECTORY_DOWNLOADS ;
    	fullPath = defalutPath + "/" + source_name;
    }
    
    public DownloadCompleteReceiver(String source_name, String resource_id,
    		String url){
    	this.source_name = source_name;
    	this.resource_id = resource_id;
    	this.url = url;
    	
    	defalutPath = Environment.getExternalStorageDirectory().getAbsolutePath() +
    										"/"+Environment.DIRECTORY_DOWNLOADS ;
    	fullPath = defalutPath + "/" + source_name;
    }
    
    //silent install and then add item to the database
    public void SilentInstall(String path){     
    	//get the install result and deal with it;
        try {
        	Process process = Runtime.getRuntime().exec("pm install -r "+ new File(path));
            Log.i("silentInstall", "install successfully~~");
           }catch(Exception e) {
             e.printStackTrace();
           }
    }
    @Override  
    public void onReceive(Context context, Intent intent) {  
        if(intent.getAction().equals(DownloadManager.ACTION_DOWNLOAD_COMPLETE)){  
            long downId = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);  
            Log.d(LOGTAG," download complete! id : "+downId);  
            Log.d(LOGTAG," path : "+ fullPath);  
    
            if(source_name.endsWith(".apk")){
            	 SilentInstall(fullPath);
                 Log.d(LOGTAG,fullPath);
                 
                 parseResourceID(resource_id);
                 Toast.makeText(context, source_name +"install success!", Toast.LENGTH_SHORT).show();
            }else if(source_name.endsWith("png") || source_name.endsWith("jpg")){
            	
            }else if(source_name.endsWith("png")){
            	
            }
           
        }  
    }  
    
    private void parseResourceID(String resourceID){
		char InfoType = resourceID.charAt(0);
		int ItemType = resourceID.charAt(1) + 0;
		int position = resourceID.charAt(2) + 0;
		switch(InfoType){
		//APK
		case '1':
			if(source_name.endsWith(".apk")){
				SilentInstall(fullPath);
				getAPKInfo(fullPath);
				//the default position is 0
				dbManager.insertAPKData(resourceID, source_name, ItemType, 
						position, appLabel, null, null, pkgName);
			}else{//If only an address is pasted
				dbManager.insertAPKData(resourceID, source_name, ItemType, position);
			}
			break;
		//VIDEO 
		case '2':
			//The default eo and tcase is:
			//show the vidhe background name and path is null;
			dbManager.insertVIDEOData(resourceID, source_name, defalutPath, ItemType, 1, null, null);
			break;
		//TV Info
		case '3':
			//TV need to look directly from uri, this place need mix
			dbManager.insertTVData(resourceID, source_name, ItemType, 1, 
									null, null, null);
			break;
		//PIC Info
		case '4': 
			//the pic need one more "relateID"
			dbManager.insertPICData(resourceID, source_name, defalutPath, ItemType, 1, null);
			break;
		default:
			break;
		}
    }
    
	public void getAPKInfo(String apkName){
		PackageInfo pi = pm.getPackageArchiveInfo(fullPath, PackageManager.GET_ACTIVITIES);
		pi.applicationInfo.sourceDir= fullPath;
		pi.applicationInfo.publicSourceDir = fullPath;
		
		appLabel = (String) pi.applicationInfo.loadLabel(pm);
		pkgName = pi.applicationInfo.packageName;
	}


}  